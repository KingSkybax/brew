Formular is a library for parsing HTML forms, configurations and other
form-like data.

Requirements
------------

- setuptools
- babel* for Date/Time Fields.
- py.test*
- bottle (for the example application)

.. note::
   Requirements with a * are optional.
